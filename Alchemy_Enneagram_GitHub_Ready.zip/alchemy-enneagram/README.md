# Alchemy Enneagram

Interactive contemplative Enneagram pattern finder focused on centers, type patterns, and transformation.

## What this is

This is a single-file static web app. It does not need a server, database, package install, or build step.

## Files

- `index.html` - the full interactive project
- `README.md` - this guide

## Run locally

Open `index.html` in a browser.

## Put it on GitHub

1. Create a new GitHub repository.
2. Upload `index.html` and `README.md` to the repository root.
3. Go to repository `Settings`.
4. Open `Pages`.
5. Under `Build and deployment`, choose:
   - Source: `Deploy from a branch`
   - Branch: `main`
   - Folder: `/root`
6. Save.

GitHub will publish the site after a short wait. The URL usually looks like:

`https://YOUR-USERNAME.github.io/YOUR-REPO-NAME/`

## Notes

This export came from the ChatGPT Site version of Alchemy Enneagram, source commit:

`7298159be0f9a9e3480466353da336887c29dc13`
